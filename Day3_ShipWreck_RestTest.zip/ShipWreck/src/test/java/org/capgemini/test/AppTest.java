package org.capgemini.test;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

import org.capgemini.controller.HomeController;

public class AppTest {

	@Test
    public void testApp() {
		HomeController hc = new HomeController();
		String result = hc.home();
        assertEquals( result, "Das Boot, reporting for duty!" );
	}
}
