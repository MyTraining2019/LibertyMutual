package org.cap.common;

public class DataAccessException extends Exception {

	private static final long serialVersionUID = -1530578540919250393L;

	public DataAccessException(String arg0) {
		super(arg0);
	}

	public DataAccessException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
