package org.cap.test;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

import org.cap.order.model.domain.OrderSummary;
import org.cap.order.model.entity.OrderEntity;
import org.cap.order.model.entity.OrderItemEntity;
import org.cap.order.model.transformer.OrderEntityToOrderSummaryTransformer;
import org.junit.Before;
import org.junit.Test;

public class OrderEntityToOrderSummaryTestClass {

	private OrderEntityToOrderSummaryTransformer target=null;
	
	@Before
	public void setUp(){
		target=new OrderEntityToOrderSummaryTransformer();
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void test_OdrerEntity_With_null() {
		OrderEntity orderEntity=null;
		target.transform(orderEntity);	
	}
	
	//Create testCase with OrderItems Successfully added.
		@Test
		public void test_withOrder_success(){
			String orderNumberFixture = UUID.randomUUID().toString();
			
			OrderEntity orderEntityFixture = new OrderEntity();
			orderEntityFixture.setOrderNumber(orderNumberFixture);
			orderEntityFixture.setOrderItemList(new LinkedList<OrderItemEntity>());
			
			OrderItemEntity item1=new OrderItemEntity();
			item1.setQuantity(3);
			item1.setSellingPrice(new BigDecimal("1"));
			orderEntityFixture.getOrderItemList().add(item1);
			
			OrderItemEntity item2=new OrderItemEntity();
			item2.setQuantity(2);
			item2.setSellingPrice(new BigDecimal("1"));
			orderEntityFixture.getOrderItemList().add(item2);
			
			OrderSummary result = target.transform(orderEntityFixture);
			
			assertNotNull(result);
			
			assertEquals(5, result.getItemCount());
			assertEquals(new BigDecimal("5.00"), result.getTotalAmount());

		}
	
	
	//Create testCase with no OrderItems
	@Test
	public void test_No_OrderItems(){
		String orderNumberFixture = UUID.randomUUID().toString();
		
		OrderEntity orderEntityFixture = new OrderEntity();
		orderEntityFixture.setOrderNumber(orderNumberFixture);
		orderEntityFixture.setOrderItemList(new LinkedList<OrderItemEntity>());
		
		OrderSummary result = target.transform(orderEntityFixture);
		
		assertNotNull(result);
		
		assertEquals(0, result.getItemCount());
		assertEquals(new BigDecimal("0.00"), result.getTotalAmount());

	}

}
