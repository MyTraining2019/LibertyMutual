package org.cap.test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Assume;
import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

@RunWith(Theories.class)
public class TheoriesTest {

	@DataPoints
	public static int[] inputData(){
		return new int[]{1,3,-7,2,13};
	}
	
	

	@Theory
	public void testNumbers(Integer num1,Integer num2) {
		System.out.println(num1 +" -->" + num2);
	
		Assume.assumeTrue(num1>0 && num2>0);
			assertTrue((num1+num2)>0);
		
	}

}
